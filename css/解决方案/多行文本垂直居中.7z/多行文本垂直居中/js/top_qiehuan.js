﻿	function getNames1(obj,name,tij) {	
				var p = document.getElementById(obj);
				var plist = p.getElementsByTagName(tij);
				var rlist = new Array();
				for(i=0;i<plist.length;i++)
				{
					if(plist[i].getAttribute("name") == name)
					{
						rlist[rlist.length] = plist[i];
					}
				}
				return rlist;
			}
			
			function fod1(obj,tag,name) {
				var p = getNames1(tag,"t","div");
				var p1 = getNames1(name,"f","div"); 
				for(i=0;i<p1.length;i++)
				{
					if(obj==p[i])
					{
						p[i].className = "btn1";
						p1[i].className = "dis";
					}
					else
					{
						p[i].className = "btn2";
						p1[i].className = "undis";
					}	
				}
			}
			
			function fod2(obj,tag,name) {
				var p = getNames1(tag,"r","div");
				var p1 = getNames1(name,"j","div"); 
				for(i=0;i<p1.length;i++)
				{
					if(obj==p[i])
					{
						p[i].className = "btn1";
						p1[i].className = "dis";
					}
					else
					{
						p[i].className = "btn2";
						p1[i].className = "undis";
					}	
				}
			}

			function fod3(obj,tag,name)
			{
				//var p = obj.parentNode.getElementsByTagName("td");
				var p = getNames1(tag,"a","div");
				var p1 = getNames1(name,"b","div"); // document.getElementById(name).getElementsByTagName("div");
				for(i=0;i<p1.length;i++)
				{
					if(obj==p[i])
					{
						p[i].className = "btn1";
						p1[i].className = "dis";
					}
					else
					{
						p[i].className = "btn2";
						p1[i].className = "undis";
					}	
				}
			}
			
			function newsCenter(id){
	        	window.open("http://www.ofweek.com/NewsCenter-"+id+".html");
	        }
			
			function fod4(obj,tag,name)
			{
				//var p = obj.parentNode.getElementsByTagName("td");
				var p = getNames1(tag,"c","div");
				var p1 = getNames1(name,"d","div"); // document.getElementById(name).getElementsByTagName("div");
				for(i=0;i<p1.length;i++)
				{
					if(obj==p[i])
					{
						p[i].className = "btn1";
						p1[i].className = "dis";
					}
					else
					{
						p[i].className = "btn2";
						p1[i].className = "undis";
					}	
				}
			}
			
			function fod5(obj,tag,name)
			{
				//var p = obj.parentNode.getElementsByTagName("td");
				var p = getNames1(tag,"e","div");
				var p1 = getNames1(name,"f","div"); // document.getElementById(name).getElementsByTagName("div");
				for(i=0;i<p1.length;i++)
				{
					if(obj==p[i])
					{
						p[i].className = "btn1";
						p1[i].className = "dis";
					}
					else
					{
						p[i].className = "btn2";
						p1[i].className = "undis";
					}	
				}
			}
			function openNew(url){
				window.open(url);
			}

