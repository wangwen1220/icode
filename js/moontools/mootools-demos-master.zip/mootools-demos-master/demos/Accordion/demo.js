
window.addEvent('domready', function(){
	new Fx.Accordion($('accordion'), '#accordion h2', '#accordion .content');
});
